SELinux policy for Container Runtimes
